package GenericBox;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);

        Box<Integer> box = new Box<>();

        int n = Integer.parseInt(console.nextLine());
        for (int i = 0; i < n; i++) {
            int input = Integer.parseInt(console.nextLine());
            box.add(input);
        }
        System.out.println(box);
    }
}
