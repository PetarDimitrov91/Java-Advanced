package GenericBox;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);

        Box<String> box = new Box<>();

        int n = Integer.parseInt(console.nextLine());
        for (int i = 0; i < n; i++) {
            String text = console.nextLine();
            box.add(text);
        }
        System.out.println(box);
    }
}
