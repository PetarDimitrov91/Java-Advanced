package StrategyPattern;

import java.util.Comparator;

public class NameLengthComparator implements Comparator<Person> {
    @Override
    public int compare(Person first, Person second) {
        int result = Integer.compare(first.getName().length(), second.getName().length());
        if (result == 0) {
            result = Integer.compare(first.getName().charAt(0), second.getName().charAt(0));
        }
        return result;
    }
}